
from utils.document_processor import extract_document_text
from utils.report_parser import parse_report_text


def _parse_extracted_text(extracted_text: str) -> dict:
    """
    Parse extracted document text using the existing report parser.
    """
    return parse_report_text(extracted_text)


def document_reader_agent(file_path: str) -> dict:
    """
    Agent 1: Document Reader

    Extraction priority:
        1. Docling
        2. Existing PyMuPDF + Tesseract pipeline

    The original extracted text is preserved for later agents.
    OCR values are not silently corrected.
    """

    warnings = []
    extracted_text = ""
    parsed_report = None
    extraction_method = None

    # --------------------------------------------------------
    # STEP 1: TRY DOCLING
    # --------------------------------------------------------

    try:
        # Import here so a missing Docling installation
        # does not prevent the existing OCR fallback.
        from utils.docling_processor import extract_with_docling

        print("\n========== DOCLING EXTRACTION ==========")

        docling_text = extract_with_docling(file_path)

        if docling_text and docling_text.strip():

            docling_report = _parse_extracted_text(docling_text)

            print(
                "Docling candidate results:",
                docling_report["result_count"],
                flush=True
            )

            # Accept Docling when the parser identifies
            # at least one candidate result.
            if docling_report["result_count"] > 0:

                extracted_text = docling_text
                parsed_report = docling_report
                extraction_method = "docling"

            else:
                warnings.append(
                    "Docling extracted content, but the parser "
                    "could not identify any test results. "
                    "Trying the existing OCR pipeline."
                )

        else:
            warnings.append(
                "Docling returned empty content."
            )

    except Exception as error:

        warnings.append(
            f"Docling extraction failed: {error}"
        )

        print(
            f"Docling failed: {error}",
            flush=True
        )

    # --------------------------------------------------------
    # STEP 2: TESSERACT FALLBACK
    # --------------------------------------------------------

    if parsed_report is None:

        print("\n========== TESSERACT FALLBACK ==========")

        try:
            tesseract_text = extract_document_text(file_path)

            tesseract_report = _parse_extracted_text(
                tesseract_text
            )

            if tesseract_report["result_count"] > 0:

                extracted_text = tesseract_text
                parsed_report = tesseract_report
                extraction_method = "tesseract"

            else:
                warnings.append(
                    "The existing OCR pipeline also failed "
                    "to identify any test results."
                )

                # Preserve the Docling output if it exists.
                # This allows later inspection of its raw text.
                if not extracted_text:
                    extracted_text = tesseract_text

                    parsed_report = tesseract_report
                    extraction_method = "tesseract"

        except Exception as error:

            warnings.append(
                f"Tesseract extraction failed: {error}"
            )

            print(
                f"Tesseract failed: {error}",
                flush=True
            )

    # --------------------------------------------------------
    # STEP 3: HANDLE COMPLETE EXTRACTION FAILURE
    # --------------------------------------------------------

    if parsed_report is None:

        return {
            "extracted_text": extracted_text,
            "parsed_report": None,
            "extraction_method": None,
            "extraction_warnings": warnings,
            "status": "error",
            "error": (
                "Both Docling and the existing OCR pipeline "
                "failed to extract the report."
            ),
        }

    # --------------------------------------------------------
    # STEP 4: DISPLAY RESULTS
    # --------------------------------------------------------

    print("\n========== SELECTED EXTRACTED TEXT ==========")
    print(extracted_text)
    print("=============================================\n")

    print(
        f"Extraction method: {extraction_method}",
        flush=True
    )

    print(
        "Extracted candidate results:",
        parsed_report["result_count"],
        flush=True
    )

    if warnings:
        print(
            "Extraction warnings:",
            warnings,
            flush=True
        )

    # --------------------------------------------------------
    # STEP 5: RETURN TO THE NEXT AGENT
    # --------------------------------------------------------

    return {
        "extracted_text": extracted_text,
        "parsed_report": parsed_report,
        "extraction_method": extraction_method,
        "extraction_warnings": warnings,
        "status": (
            "success"
            if parsed_report["result_count"] > 0
            else "needs_review"
        ),
    }
