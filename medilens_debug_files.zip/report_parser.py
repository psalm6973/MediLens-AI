from pathlib import Path
from typing import Any
import re


# ============================================================
# 1. BASIC PATTERNS AND UNIT NORMALIZATION
# ============================================================

NUMBER = r"-?\d[\d,]*(?:\.\d+)?"

UNIT_CORRECTIONS = {
    "g/dl": "g/dL",
    "g/l": "g/L",
    "gm%": "g/dL",
    "mg/dl": "mg/dL",
    "mmol/l": "mmol/L",
    "umol/l": "µmol/L",
    "µmol/l": "µmol/L",
    "ng/ml": "ng/mL",
    "pg/ml": "pg/mL",
    "iu/l": "IU/L",
    "u/l": "U/L",
    "miu/l": "mIU/L",
    "fl": "fL",
    "pg": "pg",
    "%": "%",
}

KNOWN_UNITS = {
    "g/dl", "g/l", "gm%", "mg/dl",
    "mmol/l", "umol/l", "µmol/l",
    "ng/ml", "pg/ml", "iu/l", "u/l",
    "miu/l", "fl", "pg", "%",
    "cells/ul", "cells/µl", "million/ul",
    "million/µl", "mm/hr", "mm/hour",
    "seconds", "second", "minutes", "minute",
}

METADATA_RE = re.compile(
    r"^(?:ORDER NO|HH NO|ADM NO|NAME|PATIENT NAME|"
    r"AGE|SEX|GENDER|DATE|LOCATION|REFERRED BY|"
    r"SAMPLE|WORK SHT|MAIN LAB|DEPARTMENT|"
    r"REPORT PRINTED|PAGE|CONSULTANT)\b",
    re.IGNORECASE,
)

HEADER_RE = re.compile(
    r"^(?:TEST NAME|TEST|RESULT|RESULTS|UNITS?|"
    r"REFERENCE RANGE|BIOLOGICAL REFERENCE|"
    r"HAEMATOLOGY|HEMATOLOGY|BIOCHEMISTRY|"
    r"CBC|COMPLETE BLOOD COUNT|LIVER PROFILE|"
    r"LIVER FUNCTION TEST|LFT|KIDNEY FUNCTION TEST|"
    r"KFT|RFT|LIPID PROFILE|URINALYSIS)\b",
    re.IGNORECASE,
)


# ============================================================
# 2. GENERAL HELPERS
# ============================================================

def clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def to_number(value: str) -> float:
    return float(value.replace(",", "").strip())


def normalize_unit(raw_unit: str | None):
    """
    Normalize only units that are clearly recognized.
    Unknown OCR units are preserved without guessing.
    """
    if not raw_unit:
        return None, False, False

    raw = clean_text(raw_unit)
    key = raw.lower()

    if key in UNIT_CORRECTIONS:
        normalized = UNIT_CORRECTIONS[key]
        return normalized, normalized != raw, True

    if key in KNOWN_UNITS:
        return raw, False, True

    return raw, False, False


def parse_range_parts(low_text: str, high_text: str):
    """
    Parse separately extracted lower and upper reference limits.
    A trailing OCR dash is tolerated but not used as a value.
    """
    low_match = re.search(NUMBER, low_text or "")
    high_match = re.search(NUMBER, high_text or "")

    if not low_match or not high_match:
        return None

    low = to_number(low_match.group())
    high = to_number(high_match.group())

    if low > high:
        return None

    return {
        "type": "range",
        "low": low,
        "high": high,
    }


def check_reference_status(value, reference_range):
    if not reference_range:
        return "unknown"

    if value < reference_range["low"]:
        return "below"

    if value > reference_range["high"]:
        return "above"

    return "within"


def extract_flag(raw_flag: str | None):
    if not raw_flag:
        return None

    flag = clean_text(raw_flag).upper()

    mapping = {
        "H": "high",
        "HIGH": "high",
        "L": "low",
        "LOW": "low",
        "ABNORMAL": "abnormal",
        "CRITICAL": "critical",
    }

    return mapping.get(flag)


def normalize_test_name(name: str) -> str:
    name = clean_text(name)
    name = re.sub(r"[()]", " ", name)
    name = re.sub(
        r"\b(?:conventional|s\.?\s*i\.?|s\.?1\.?)\b",
        "",
        name,
        flags=re.IGNORECASE,
    )

    name = re.sub(
        r"\b(?:serum|plasma|enzymatic|calculated)\b",
        "",
        name,
        flags=re.IGNORECASE,
    )

    name = re.sub(r"\s+", " ", name).strip(" :;|.-")

    # Safe display-name normalization.
    aliases = {
        "globulin": "Globulin",
        "bilirubin total": "Total Bilirubin",
        "bilirubin": "Total Bilirubin",
        "a/g ratio": "A/G Ratio",
    }

    key = name.lower()

    if key in aliases:
        return aliases[key]

    return name


def is_valid_test_label(name: str) -> bool:
    name = clean_text(name)

    if len(name) < 2:
        return False

    if METADATA_RE.search(name) or HEADER_RE.search(name):
        return False

    if re.fullmatch(r"[\d\s.,:/-]+", name):
        return False

    return True


def is_si_marker(value: str) -> bool:
    """
    Recognize common S.I. OCR variations without treating
    arbitrary text as an S.I. marker.
    """
    cleaned = clean_text(value).upper()
    cleaned = cleaned.replace(" ", "").replace(",", "")

    return cleaned in {
        "S.I.",
        "S.I",
        "S.1.",
        "S.1",
        "SI",
        "S1",
    }


def is_conventional_marker(value: str) -> bool:
    return clean_text(value).lower() == "conventional"


def make_review_reasons(
    value_ambiguous: bool,
    unit_recognized: bool,
    raw_unit: str | None,
):
    reasons = []

    if value_ambiguous:
        reasons.append("Multiple numeric candidates detected")

    if raw_unit and not unit_recognized:
        reasons.append(
            "Unit could not be confidently normalized; "
            "verify it against the original report"
        )

    return reasons


# ============================================================
# 3. CREATE A STANDARD RESULT ENTRY
# ============================================================

def create_test_entry(
    test_name: str,
    value_text: str,
    raw_unit: str | None,
    raw_flag: str | None,
    reference_range: dict | None,
    original_line: str,
):
    value = to_number(value_text)

    normalized_unit, unit_corrected, unit_recognized = (
        normalize_unit(raw_unit)
    )

    # A missing unit is not automatically an error.
    # Some measurements, such as ratios, are unitless.
    value_ambiguous = False

    reasons = make_review_reasons(
        value_ambiguous,
        unit_recognized,
        raw_unit,
    )

    flag = extract_flag(raw_flag)

    return {
        "test_name": clean_text(test_name),

        "value": value,
        "raw_ocr_value": value_text,
        "value_candidates": [value],
        "value_ambiguous": value_ambiguous,

        "unit": normalized_unit,
        "raw_ocr_unit": raw_unit,
        "unit_correction_applied": unit_corrected,

        "reference_range": reference_range,
        "flag": flag,

        "reference_status": check_reference_status(
            value,
            reference_range,
        ),

        "alternate_values": [],

        "needs_review": bool(reasons),
        "needs_review_reasons": reasons,

        "correction_applied": unit_corrected,
        "original_line": original_line,
    }


# ============================================================
# 4. GROUP S.I. VALUES WITH THEIR PRIMARY TEST
# ============================================================

def attach_alternate_value(primary: dict, alternate: dict):
    """
    Preserve the S.I. representation separately.
    Never overwrite the primary result.
    """
    primary["alternate_values"].append({
        "value": alternate["value"],
        "raw_ocr_value": alternate["raw_ocr_value"],
        "value_candidates": alternate["value_candidates"],
        "value_ambiguous": alternate["value_ambiguous"],

        "unit": alternate["unit"],
        "raw_ocr_unit": alternate["raw_ocr_unit"],

        "reference_range": alternate["reference_range"],
        "flag": alternate["flag"],
        "reference_status": alternate["reference_status"],

        "unit_correction_applied": (
            alternate["unit_correction_applied"]
        ),

        "needs_review": alternate["needs_review"],
        "needs_review_reasons": alternate["needs_review_reasons"],

        "original_line": alternate["original_line"],
    })

    if alternate["needs_review"]:
        primary["needs_review"] = True

        for reason in alternate["needs_review_reasons"]:
            if reason not in primary["needs_review_reasons"]:
                primary["needs_review_reasons"].append(reason)


# ============================================================
# 5. DOCLING MARKDOWN TABLE PARSER
# ============================================================

def split_markdown_row(line: str) -> list[str]:
    """
    Convert a Markdown table row into individual cells.
    """
    line = line.strip()

    if not line.startswith("|"):
        return []

    if line.endswith("|"):
        line = line[1:-1]
    else:
        line = line[1:]

    return [clean_text(cell) for cell in line.split("|")]


def is_markdown_separator(cells: list[str]) -> bool:
    if not cells:
        return False

    return all(
        re.fullmatch(r":?-{2,}:?", cell.replace(" ", ""))
        for cell in cells
    )


def parse_markdown_table_row(line: str):
    """
    Expected Docling layout:

    | Test | Test | Test | Result | Units | Status |
    | Reference low | Reference high |

    The first column contains the test name.
    The third column identifies Conventional or S.I.
    """
    cells = split_markdown_row(line)

    if len(cells) < 6:
        return None

    if is_markdown_separator(cells):
        return None

    # The Docling table used by Report 4 has eight columns.
    # Keep the positions explicit so duplicate column headings
    # do not cause values to be assigned to the wrong field.
    test_label = cells[0]
    method_label = cells[2]
    value_text = cells[3]
    raw_unit = cells[4] or None
    raw_flag = cells[5] or None

    if not is_valid_test_label(test_label):
        return None

    if not re.fullmatch(NUMBER, value_text.replace(",", "")):
        return None

    reference_range = None

    if len(cells) >= 8:
        reference_range = parse_range_parts(
            cells[6],
            cells[7],
        )

    # A row is an alternate only when the row is clearly
    # an S.I. representation and its label is Serum or Plasma.
    is_method_row = bool(
        re.match(
            r"^(?:serum|plasma)$",
            test_label,
            re.IGNORECASE,
        )
    )

    si_row = is_si_marker(method_label)

    if is_method_row and si_row:
        return {
            "row_type": "alternate",
            "value_text": value_text,
            "raw_unit": raw_unit,
            "raw_flag": raw_flag,
            "reference_range": reference_range,
            "original_line": line,
        }

    # Do not merge a calculated result such as A/G Ratio
    # merely because its label contains the word Serum.
    test_name = normalize_test_name(test_label)

    if not test_name:
        return None

    return {
        "row_type": "primary",
        "test_name": test_name,
        "value_text": value_text,
        "raw_unit": raw_unit,
        "raw_flag": raw_flag,
        "reference_range": reference_range,
        "original_line": line,
    }


def parse_markdown_tables(lines: list[str]):
    results = []
    unparsed_lines = []

    for line in lines:
        if not line.strip().startswith("|"):
            continue

        cells = split_markdown_row(line)

        if is_markdown_separator(cells):
            continue

        parsed = parse_markdown_table_row(line)

        if parsed is None:
            unparsed_lines.append(line)
            continue

        if parsed["row_type"] == "alternate":
            if results:
                alternate = create_test_entry(
                    test_name=results[-1]["test_name"],
                    value_text=parsed["value_text"],
                    raw_unit=parsed["raw_unit"],
                    raw_flag=parsed["raw_flag"],
                    reference_range=parsed["reference_range"],
                    original_line=parsed["original_line"],
                )

                attach_alternate_value(results[-1], alternate)
            else:
                unparsed_lines.append(line)

            continue

        entry = create_test_entry(
            test_name=parsed["test_name"],
            value_text=parsed["value_text"],
            raw_unit=parsed["raw_unit"],
            raw_flag=parsed["raw_flag"],
            reference_range=parsed["reference_range"],
            original_line=parsed["original_line"],
        )

        results.append(entry)

    return results, unparsed_lines


# ============================================================
# 6. PLAIN-TEXT PARSER FALLBACK
# ============================================================

PLAIN_ROW_RE = re.compile(
    rf"^(?P<label>.*?)\s+(?P<value>{NUMBER})\s+(?P<right>.*)$"
)

PLAIN_RANGE_RE = re.compile(
    rf"(?P<low>{NUMBER})\s*(?:-|–|—|to)\s*"
    rf"(?P<high>{NUMBER})",
    re.IGNORECASE,
)

PLAIN_UNIT_RE = re.compile(
    r"\b(?:g/dl|g/l|mg/dl|mmol/l|umol/l|µmol/l|"
    r"ng/ml|pg/ml|iu/l|u/l|miu/l|fl|pg|%)\b",
    re.IGNORECASE,
)


def parse_plain_text_row(line: str):
    match = PLAIN_ROW_RE.match(line.strip())

    if not match:
        return None

    label = clean_text(match.group("label"))
    value_text = match.group("value")
    right = clean_text(match.group("right"))

    if not is_valid_test_label(label):
        return None

    range_match = PLAIN_RANGE_RE.search(right)

    reference_range = None

    if range_match:
        low = to_number(range_match.group("low"))
        high = to_number(range_match.group("high"))

        if low <= high:
            reference_range = {
                "type": "range",
                "low": low,
                "high": high,
            }

    unit_match = PLAIN_UNIT_RE.search(right)
    raw_unit = unit_match.group(0) if unit_match else None

    flag_match = re.search(
        r"\b(H|L|HIGH|LOW|ABNORMAL|CRITICAL)\b",
        right,
        re.IGNORECASE,
    )

    raw_flag = flag_match.group(0) if flag_match else None

    # Avoid accepting lines that contain no supporting
    # result information beyond the numeric value.
    if not raw_unit and not reference_range and not raw_flag:
        return None

    return create_test_entry(
        test_name=normalize_test_name(label),
        value_text=value_text,
        raw_unit=raw_unit,
        raw_flag=raw_flag,
        reference_range=reference_range,
        original_line=line,
    )


def parse_plain_text(lines: list[str]):
    results = []
    unparsed_lines = []

    for line in lines:
        if METADATA_RE.search(line):
            continue

        if HEADER_RE.search(line):
            continue

        if re.fullmatch(r"[-_|. ]+", line):
            continue

        entry = parse_plain_text_row(line)

        if entry is None:
            unparsed_lines.append(line)
            continue

        results.append(entry)

    return results, unparsed_lines


# ============================================================
# 7. MAIN REPORT PARSER
# ============================================================

def parse_report_text(text: str) -> dict[str, Any]:
    if not isinstance(text, str):
        raise TypeError("Report text must be a string.")

    if not text.strip():
        raise ValueError("Report text is empty.")

    lines = [
        clean_text(line)
        for line in text.splitlines()
        if line.strip()
    ]

    has_markdown_table = any(
        line.strip().startswith("|")
        for line in lines
    )

    if has_markdown_table:
        results, unparsed_lines = parse_markdown_tables(lines)
        parser_version = "4.0-markdown"
    else:
        results, unparsed_lines = parse_plain_text(lines)
        parser_version = "4.0-plain"

    return {
        "results": results,

        "unassigned_values": [],
        "unparsed_lines": unparsed_lines,

        "result_count": len(results),
        "unassigned_value_count": 0,

        "parser_version": parser_version,

        "disclaimer": (
            "Extracted values are unverified report candidates. "
            "Test names, values, units and reference ranges must "
            "be checked against the original report. "
            "This parser does not provide medical diagnoses "
            "or treatment recommendations."
        ),
    }


# ============================================================
# 8. PARSE TEXT FILE
# ============================================================

def parse_report_file(file_path: str) -> dict[str, Any]:
    path = Path(file_path)

    if not path.is_file():
        raise FileNotFoundError(
            f"Report text file not found: {path}"
        )

    text = path.read_text(encoding="utf-8")

    return parse_report_text(text)