I5O9001

Rac MEA

Sample Type

:Mis.APARNA

:45 Y(s) / Female

: Serum

Patient Name Age /Gender Refered By Ref Customer :

## TEST NAME

Metnod : lmmuno tarbidimeoy

C-Reactive Protein (CRP)

## Interpretation

CRP

(C-Reactive Protein) is an acute-phase protein produced by liver in response to indlammation or infection CAP is a useful marker od inflamation because its levels in the blood increases rapidy in response to inflammatory Stimoliand decreases quickly once the infammation has cesolved.CRP levels in aucommune dsease may show litle or no increase in condtions ike pregnancy, angina seizeires ,asthma or common cold The maln limitation of cap is in its mon-specific response and should not be interpreted without a co-plete cinicalessay and evaluation

Or.Abdur RehmanAsif Consultant Biochemist

23-10-2026 17:48

Suggested Cinical Comelation If Necessary Kincty Discuss With the Sigmatary

## Healmax Diagnostics Pvt.Ltd

print Date:

Por No &amp; at-5 u a/t Ouga Nager ColorcAee. Ooa ae Chendema Srcenes, Hycerebed Tengena Soo D:5555782782/9083 059797-We66k.wwwhealmin Page 1 01.7

<!-- image -->

SID Collected Registered Accepted Reported Fr Code Barcode

- :HM1085265
- :23-10-202614:06
- :23-10-2026 14:04
- :23-10-202614:54
- :23-10-2026 16:33
- :TS696
- :F822551

## BIOCHEMISTRY

## C-Reactive Protein (CRP)

RESULTS

5.3

mg/L

BIOLOGICAL REFERENCEINYERVALS

0.0-8.0

UNIYS