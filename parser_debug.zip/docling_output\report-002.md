afied medicat

imax Diagnosthea I509001

RaC-MEA

恭

Patient Name Ace/Gender Refered By Ref Customer Sample Type

- :Mrs.APARNA
- : 45 Y(s) / Female
- : Whole Blood Sodium Citrate

<!-- image -->

SID Colected Registered Accepted Reported Fr Code Barcode

- :HM1085265
- :23-10-2026 14:06
- :23-10-2026 14:04
- :23-10-202614:06
- :23-10-2026 15:22
- :YS696
- :F822550

## HAEMATOLOGY

## ESR(Erythrocyte Sedimentation Rate)

RESULTS

UNIYS

Exythrocyte Sedimentation Rate

35.

mm 1st Hour BIOLOGICAL REFERENCE INTERVALS

0-15 (Male)

## TESTNAME

(ESR)

Metted lesleprer Melted

## Interpretation

0-20 (Female)

ES&amp; is a pecgmostic marker for many disease sinnificant in chronic ilness alpng with other parameters.

Dr.A.VLJAYA KUMAR MBBS DCP

Prng Date: 23-10-2026 17:45 "Sasoested Cliwical Correlation It Necessary indy Discuss With the Signatory

Page 6 ot 7

## Healmax Diagnostics Pvt.Ltd

Plor No &amp;. e-5 toea/eGrt Ouga Nagar Coloey Amwepet Opp Lare Chancana Ricehers Hyoertad Teangae-50026 Cam:5553782782/9583059727-Webwxe:wwwdwaimaxin

<!-- image -->