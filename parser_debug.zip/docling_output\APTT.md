<!-- image -->

## VIJAYA A DIAGNOSTIC CENTRE

<!-- image -->

HNo. 2-137/10, Plot No.42, NH65, Opposite R.S. Brothers, Gangaram, Chanda Nagar, Hyderabad -500050, Telangana

## TEST REPORT

Name

: Ms. KEERTHANA S

Age/Gender

: 18 Years / Female BirthDate : 15-Nov-2007

Registeredon:04-Aug-2026 14:55

Collected on:04-Aug-202614:57

Registration ID:260200045974

Released on:04-Aug-202619:25

Ref. By

: Dr RAJASEKHAR CHAKRAVARTHY

Printedon

:06-Aug-202612:39

Sample Type

: WB Citrate Regn Centre : Kukatpally - 20

## ACTIVATED PARTIAL THROMBOPLASTIN TIME (APTT)

TESTNAME

RESULT

UNIT

BIOLOGICALREFERENCEINTERVAL

APTT

31.9

Seconds

27.6to35.9

Method: ElectromechanicalClotDetection

MNAPTT

31.7

Seconds

## Interpretation / Limitations :

- APTT measures intrinsic pathway (Factor XII, XI, IX &amp; VIII) and common pathway (Factors II, V, X &amp; Fibrinogen) factors of the coagulation cascade.
- Isolated APTTprolongation can be caused by :
- Deficiency of factors VIII, IX &amp; XI (associated with bleeding)
- Deficiency of factor XII, Prekallikrein, Highmolecular weight kininogen &amp; Lupus anticoagulants (not associated with bleeding)
- Combined Prolonged APTT and PT can be caused by:
- Oral Anticoagulants, Heparin
- Disseminated intravascular coagulation (DIC)
- Liver Disease
- Vitamin K Deficiency
- Massive transfusion
- Dysfibrinogenemia, factor X, V and II defects

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->