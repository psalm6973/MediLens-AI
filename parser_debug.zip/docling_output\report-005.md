gnowt

<!-- image -->

<!-- image -->

<!-- image -->

Patient Name Age /Gender Sample Type Ref Customer Refered By

Mrs.APARNA :45 Y(s) / Female

: Serum

## TEST NAME

Rheumatold Factor (RA test)

Michod Imeano lubidnc

## Interpretation

indicates that the specimen contains meumatoid factors. RF is not only specific for rheumatold arthncis but it also frequenty appears in cases of other systemic inflammatory diseases and chronic infections.

<!-- image -->

<!-- image -->

<!-- image -->

Dr.Abdur RehmanAsif Consultant Blochemist

"Suggelted Cinical Comrelsion Ir Necessary Kindly Olscuss Wiot the Sigratory

Page 4 a1 7

<!-- image -->

- :HM1085265

BIOLOGICAL REFERENCE INTERVALS

SID Collected Registered Accepted Reported Fr Code Baroode

- :23-10-2026 14:06
- :23-10-2026 14:04
- :23-10-2026 14:54
- :23-10-2026 16:33
- :TS696
- :F822551

<!-- image -->

## BIOCHEMISTRY

## Rheumatoid Factor (RA test)

RESULTS

UNITS

10/mL

&lt;18

312.1

Print Dane

<!-- image -->

23-10-2076 17/48

Pic No. -  Da Nage ColbyAmepet O Lee Chandina Bden deabad Teangana5 Ca4. 9551 782 782 /9905 05 9092-V0840K wwwbealnaain

## Healmax Diagnostics Pvt.Ltd