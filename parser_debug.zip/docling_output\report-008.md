<!-- image -->

<!-- image -->

## VIJAYA DIAGNOSTIC CENTRE®

H No. 2-137/10, Plot No.42, NH65, Opposite R.S. Brothers, Gangaram, Chanda Nagar, Hyderabad - 500050, Telangana

## TEST REPORT

Name

: Ms. KEERTHANA S

Registered on:04-Aug-202614:55

Age/Gender

: 18 Years / Female BirthDate: 15-Nov-2007

Collectedon:04-Aug-202614:57

RegistrationID:260200045974

Released on:04-Aug-202621:13

Ref. By

Sample Type

: Dr RAJASEKHAR CHAKRAVARTHY

Printed on

: 06-Aug-2026 12:39

: Urine Regn Centre: Kukatpally - 20

## URINE PROTEIN CREATININE RATIO - SPOT

TEST NAME

RESULT

UrineProtein

260

Method: Pyrogallol Red

Urine Creatinine

201.11

UNIT mg/dL

mg/dL

BIOLOGICAL REFERENCE INTERVAL

Not established

16-327

Method: JaffeKinetic IDMS traceable

Protein Creatinine Ratio

1.29

0- 0.2

Method: Calculation

Interpretation /Limitations :

Normal

&lt;0.2

Significant Proteinuria 0.2 - 3.5

Nephrotic Syndrome

&gt; 3.5

- Under most circumstances untimed (spot) urine samples be used to detect and monitor proteinuria in children and adults.
- paets e s s sedP- ds s  anb od s  wt is ssed as having persistent proteinuria and undergo further evaluation and management for Chronic kidney disease.
- Orthostatic proteinuria must be excluded by repeat measurements on first morning specimen if the initial findings of proteinuria was obtained on a random specimen.