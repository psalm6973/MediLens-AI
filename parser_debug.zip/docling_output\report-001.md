<!-- image -->

<!-- image -->

<!-- image -->

Patient Name

: Mrs APARNA

Refered By

Age /Gender

: 45 Y(s) / Female

Ref Customer

Sample Type

:WB-EDTA

<!-- image -->

SID

Collected

:23-10-2026 14:06

Registered

Reported

Accepted

Fr Code

:HM1085265

:23-10-2026 14:04

:23-10-202614:29

:23-10-2026 14:05

:1S696

Baroode

:F822550

<!-- image -->

## HAEMATOLOGY

## CBC-Complete Blood Count

## Peripheral Smear Examination

| TESINAME                                  | RESULTS   | UNITS                 | Bio.Ref.Interval   |
|-------------------------------------------|-----------|-----------------------|--------------------|
| Haemoglobin                               | 6.7       | gm%                   | 11.5-16.0          |
| Tetal RBC Count mechad: Impedaoce         | 3.8       | Millions/cumm 4.0-5.2 |                    |
| Total WBC count                           | 6.100     | cells/cumm            | 4,000-11,000       |
| Platelet Count Mectod lmvetesce           | 5'3       | Lakhs/Cumm            | 1.5-4.5            |
| PCV/Hematocrit Methad: Naveric Drtegraoon | 25.9      | 55 Vol                | 36.0-46.0 %6Vcl    |
| MCV Meanad. caksveted                     | 56.4      | n                     | 70-100             |
| HOW Manod: Calcaleted                     | 14.3      | pg                    | 27-32              |
| MCHC Memoo= Catcalated                    | 25.5      | g/dL                  | 32-36              |
| RDWCV Metred: Caltolaoed                  | 20.7      | 5%                    | 11.6-14.0          |
| Differential Count                        |           |                       |                    |
| Neutrophils                               | 66        | 9%                    | 40-75              |
| Lymphocytes                               | 22        | 96                    | 20-40              |
| Eosinophils                               | CO        |                       | 0-6                |
| Monocytes                                 | 09        |                       | 2-10               |
| Basophils                                 | 00        | 96                    | 0.0-1.0            |

RBC

WBC

Microcytie Hypochromic with Anisopeikilocytosis

Normal in Morohology.

Platelets Thrombocytos's.

Print Date:

<!-- image -->

23-10-2026 17:48

Mot No &amp; -5 8G Drga hage Coloy Aeepec Ope Lane Chandana Breers Hydmabad, Telangana-So00 Cal 9555782 70219909 05 5757-Viet6ta wwehaalmakin

<!-- image -->

<!-- image -->

Dr.A.VIJAYA KUMAR MBBS DCP

-Suggested Cinical Comelation In Necessary Kindiy Discuss With the Signatory

Page 2 ol 7

## Healmax Diagnostics Pvt.Ltd